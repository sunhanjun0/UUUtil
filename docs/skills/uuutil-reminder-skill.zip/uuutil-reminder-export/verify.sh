#!/bin/bash
echo "=== UUUtil Reminder Skill 自检 ==="
echo ""

echo -n "1. uuutil 命令: "
if command -v uuutil >/dev/null 2>&1; then
    echo "✓ 已安装"
else
    echo "✗ 未找到 uuutil 命令，请执行 npm link"
    exit 1
fi

echo -n "2. 应用端口 17878: "
if curl -sS http://127.0.0.1:17878/ping 2>/dev/null | grep -q ok; then
    echo "✓ 正常"
else
    echo "✗ 未连接，请启动 UUUtil 应用"
    exit 1
fi

echo -n "3. reminder.notify 接口: "
RESULT=$(uuutil call reminder.notify --json '{"source":"verify","title":"自检通知","type":"info"}' 2>/dev/null)
if echo "$RESULT" | grep -q ok; then
    echo "✓ 正常"
else
    echo "✗ 失败: $RESULT"
    exit 1
fi

echo -n "4. reminder.list 接口: "
RESULT=$(uuutil call reminder.list --json '{"limit":1}' 2>/dev/null)
if echo "$RESULT" | grep -q ok; then
    echo "✓ 正常"
else
    echo "✗ 失败: $RESULT"
    exit 1
fi

echo ""
echo "✅ 全部检查通过，技能可用！"
