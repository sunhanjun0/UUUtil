# uuutil-reminder 技能导出包

## 前置依赖

目标环境必须满足：
1. `uuutil` 命令已加入 PATH（`npm link` 过）
2. UUUtil 桌面应用运行中（端口 `127.0.0.1:17878` 可访问）
3. FIE 引擎（端口 17879）可选，仅用于 focus 上报，reminder 不依赖它

## 快速验证

```bash
# 验证 CLI 可用
uuutil call reminder.list --json '{"limit":1}'

# 验证 notify
uuutil call reminder.notify --json '{"source":"import-test","title":"导入成功","type":"info"}'
```

## 各系统导入方式

### 1. Codex / OpenAI CodeLlama 类

把 `SKILL.md` 放在技能目录下，通常是：
- macOS: `~/.codex/skills/uuutil-reminder/SKILL.md`

重启 Codex 即可自动加载。

### 2. Claude Code

```bash
mkdir -p ~/.claude/skills/uuutil-reminder
cp SKILL.md ~/.claude/skills/uuutil-reminder/

# 或者单会话临时加载
claude --skill uuutil-reminder
```

### 3. Vibe Coding / 自定义 Agent 系统

把 `SKILL.md` 的内容作为系统提示词的一部分注入即可，无需额外配置。

### 4. 私有技能仓库

直接提交 `SKILL.md` 到你的 Git 技能仓库，按目录组织即可。

## 注意事项

- 技能只发提醒，不做任何本地写操作，安全无副作用
- 应用没开时 CLI 会静默失败，不会阻塞 Agent 主流程
- notify 是单向、ask 是阻塞的，超时默认 300s，会自动放行
